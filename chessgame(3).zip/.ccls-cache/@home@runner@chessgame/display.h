#include "chess_types.h"


void display_prices(wchar_t piece);

void displayBoard(ChessPiece board[BOARD_SIZE][BOARD_SIZE]);